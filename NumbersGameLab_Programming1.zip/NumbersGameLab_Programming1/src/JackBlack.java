import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class JackBlack {
    public static void main(String[] arg) {
        System.out.println("");
        System.out.println("Welcome to JackBlack!");
        System.out.println("");
        System.out.println("It's just like the classic blackjack you know and love!");
        System.out.println("Except, you both have to share a starting hand that already adds up to 21 or less.");
        System.out.println("Also, you can pick any card! But only as long as it's a 1 or 2. This subtracts from the hand.");
        System.out.println("The player who brings it to zero or below wins!");
        System.out.println("");
        System.out.println("Good luck!");
        System.out.println("");
        String replay = "Y";
        while(replay.contains("Y") || replay.contains("y")) {
            int starting_hand = 10 + (int) (Math.random() * ((21 - 10) + 1));
            String winner = play_game(starting_hand);
            System.out.println(winner + " won! Play again? [y/n + enter]");
            Scanner replay_prompt = new Scanner(System.in);
            replay = replay_prompt.nextLine();
        }
        System.out.println("Understandable, have a nice day.");
    }
    public static int get_guess_from_player(String current_player) {
        int guess = 0;
        try {
            System.out.print("Enter '1' or '2' :  ");
            Scanner enter_guess = new Scanner(System.in);
            guess = enter_guess.nextInt();
        } catch (Exception e) {
            System.out.println("Not even an integer! Did you read the rules?");
        }
        return guess;
    }
    public static int one_user_turn(String current_player) {
        boolean valid_guess = false;
        int guess = 0;
        System.out.println(current_player + ", it's your turn!");
        int patience3 = 4;
        while (!valid_guess) {
            guess = get_guess_from_player(current_player);
            if (guess == 1 || guess == 2) {
                valid_guess = true;
            } else {
                if (patience3>=1) {
                    System.out.println("Not a 1 or a 2! Do it again!");
                    patience3 = (patience3 - 1);
                } else {
                    if (patience3==0){
                        System.out.println("Lucky for you, I was not programmed by someone who could figure out how to skip your turn in disgust if we ever got to this point.");
                    }
                }
            }
        }
        System.out.println("");
        return guess;
    }
    public static String play_game(int starting_hand){
         System.out.println("Enter player names to begin");
         System.out.println("");
         String player1 = ready_player_one();
         String player2 = ready_player_two();
         System.out.println("Your starting hand is: " + starting_hand);
         System.out.println("");
         String current_player = player1;
         int hand = starting_hand;
         while (hand >= 0) {
             int one_or_two = one_user_turn(current_player);
             hand = (hand - one_or_two);
             if (hand <= 0) {
                 break;
             }
             System.out.println("Current hand is: " + hand);
             System.out.println("");
             if (current_player == player1) {
                 current_player = player2;
             } else {
                 current_player=player1;
             }
         }
         System.out.println("And we're down to " + hand + "!");
         String winner = current_player;
         return winner;
         }
    public static String ready_player_one() {
        String player1 = "";
        int patience1 = 4;
        System.out.print("Player One: ");
        while (player1.isEmpty()) {
            Scanner enter_player1 = new Scanner(System.in);
            player1 = enter_player1.nextLine();
            if (player1.isEmpty()) {
                patience1 = (patience1 - 1);
                if (patience1 == 0) {
                    System.out.println("Seriously, your name. Please.");
                }
                if (patience1 == -5) {
                    System.out.println("I could do this all day, kiddo.");
                }
            }
        }
        return player1;
    }
    public static String ready_player_two(){
        String player2 = "";
        int patience2 = 4;
        System.out.print("Player Two: ");
        while (player2.isEmpty()) {
            Scanner enter_player2 = new Scanner(System.in);
            player2 = enter_player2.nextLine();
            if (player2.isEmpty()) {
                patience2 = (patience2 - 1);
                if (patience2==0){
                    System.out.println("Can you please call yourself something?");
                }
                if (patience2==-5) {
                    System.out.println("Ugh, I'm glad I'm not real.");
                }
            }
        }
        System.out.println("");
        return player2;
    }
}
